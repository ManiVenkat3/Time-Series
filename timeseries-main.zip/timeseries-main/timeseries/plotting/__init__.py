from .pyplot_fig_with_vertical_subplots import fig_with_vertical_subplots
from .pyplot_ax_settings import ax_settings
from .plot_stats import plot_stats
from .plotly_legend import add_label, show_only_this_labels
